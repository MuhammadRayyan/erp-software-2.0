"use client";
import { useRouter } from "next/navigation";
import { FormError } from "@/components/form-error";
import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { Columns3, LoaderCircle, Plus, Trash2 } from "lucide-react";
import { useFieldArray, useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatMoney } from "@/core/format";
import { minorToCurrencyInput, parseCurrencyAmountToMinor } from "@/modules/currency/conversion";
import { calculateTax, multiplyMoneyByQuantity, parseQuantityToMicros } from "@/modules/accounting/calculations/money";
import { savePurchaseOrderAction } from "./actions";
import { purchaseOrderInputSchema, type PurchaseOrderInput } from "./purchase-order-input";
import type { PurchaseOrderStatus } from "./purchase-order-service";
import { DocumentCurrencyFields, type DocumentCurrencyOption, type DocumentRateOption } from "@/modules/currency/document-currency-fields";
import { DocumentFormFooter } from "@/components/document-form-footer";
import { SelectNative } from "@/components/ui/select-native";

type Option = { id: string; name: string; defaultCurrencyCode: string | null };
type AccountOption = { id: string; code: string; name: string };
type TaxOption = { id: string; name: string; rateBasisPoints: number };
type ProjectOption = { id: string; code: string; name: string };
type ItemOption = { id: string; sku: string | null; name: string; purchasePriceMinor: number | null; inventoryAssetAccountId: string };

function previewLine(line: PurchaseOrderInput["lines"][number] | undefined, taxCodes: TaxOption[], minorUnit: number) {
  try {
    const unitPriceMinor = parseCurrencyAmountToMinor(String(line?.unitPrice || "0"), minorUnit, "Unit price");
    const quantityMicros = parseQuantityToMicros(String(line?.quantity || "0"));
    const netMinor = multiplyMoneyByQuantity(unitPriceMinor, quantityMicros);
    const rate = taxCodes.find((tax) => tax.id === line?.taxCodeId)?.rateBasisPoints ?? 0;
    const taxMinor = calculateTax(netMinor, rate);
    return { netMinor, taxMinor, grossMinor: netMinor + taxMinor };
  } catch { return { netMinor: 0, taxMinor: 0, grossMinor: 0 }; }
}

export function PurchaseOrderForm({ businessId, orderId, status = "draft", suppliers, expenseAccounts, taxCodes, projects, items, currency, currencies, rates, initial }: { businessId: string; orderId?: string; status?: PurchaseOrderStatus; suppliers: Option[]; expenseAccounts: AccountOption[]; taxCodes: TaxOption[]; projects: ProjectOption[]; items: ItemOption[]; currency: string; currencies: DocumentCurrencyOption[]; rates: DocumentRateOption[]; initial: PurchaseOrderInput }) {
  const router = useRouter();
  const [serverError, setServerError] = useState("");
  const [showLineProjects, setShowLineProjects] = useState(() => initial.lines.some((line) => Boolean(line.projectId)));
  const form = useForm<PurchaseOrderInput>({ resolver: zodResolver(purchaseOrderInputSchema), defaultValues: initial });
  const { register, control, handleSubmit, setError, setValue, formState: { errors, isSubmitting } } = form;
  const { fields, append, remove } = useFieldArray({ control, name: "lines" });
  const lines = useWatch({ control, name: "lines" }) ?? [];
  const currencyCode = useWatch({ control, name: "currencyCode" }) || currency; const exchangeRateToBase = useWatch({ control, name: "exchangeRateToBase" }) || ""; const exchangeRateDate = useWatch({ control, name: "exchangeRateDate" }) || ""; const exchangeRateSource = useWatch({ control, name: "exchangeRateSource" }) || ""; const orderDate = useWatch({ control, name: "date" }) || "";
  const minorUnit = currencies.find((entry) => entry.code === currencyCode)?.minorUnit ?? 2;
  const previews = lines.map((line) => previewLine(line, taxCodes, minorUnit));
  const subtotalMinor = previews.reduce((sum, row) => sum + row.netMinor, 0);
  const taxMinor = previews.reduce((sum, row) => sum + row.taxMinor, 0);
  const defaultTax = taxCodes.find((item) => item.rateBasisPoints === 500)?.id ?? taxCodes[0]?.id ?? "";
  const defaultExpense = expenseAccounts[0]?.id ?? "";
  function selectItem(index: number, itemId: string) { const item = items.find((entry) => entry.id === itemId); if (!item) { form.setValue(`lines.${index}.expenseAccountId`, defaultExpense); return; } form.setValue(`lines.${index}.description`, item.name); form.setValue(`lines.${index}.unitPrice`, minorToCurrencyInput(item.purchasePriceMinor ?? 0, minorUnit)); form.setValue(`lines.${index}.expenseAccountId`, item.inventoryAssetAccountId); }
  async function save(values: PurchaseOrderInput, intent: "draft" | "issue") {
    setServerError("");
    const result = await savePurchaseOrderAction(businessId, orderId ?? null, values, intent);
    if (result.fieldErrors) for (const [field, messages] of Object.entries(result.fieldErrors)) setError(field as keyof PurchaseOrderInput, { message: messages[0] });
    if (result.error) setServerError(result.error);
  }
  const cancelHref = orderId ? `/b/${businessId}/purchases/orders/${orderId}` : `/b/${businessId}/purchases/orders`;
  return <form className="space-y-7" noValidate>
    {serverError && <FormError message={serverError} />}
    <section className="border-b border-border pb-7"><h2 className="text-base font-semibold">Order details</h2><p className="mt-1 text-sm text-muted-foreground">Purchase orders are operational documents and never post to the ledger.</p><div className="mt-5 grid gap-5 md:grid-cols-3">
      <div className="space-y-1.5"><Label htmlFor="supplierId">Supplier</Label><SelectNative id="supplierId"  {...register("supplierId", { onChange: (event) => { if (status === "draft") { const code = suppliers.find((supplier) => supplier.id === event.target.value)?.defaultCurrencyCode ?? currency; setValue("currencyCode", code); setValue("exchangeRateToBase", code === currency ? "1" : ""); setValue("exchangeRateDate", code === currency ? orderDate : ""); setValue("exchangeRateSource", code === currency ? "Base" : ""); } } })} aria-invalid={!!errors.supplierId}><option value="">Choose a supplier…</option>{suppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</SelectNative>{errors.supplierId && <p className="field-error">{errors.supplierId.message}</p>}</div>
      <div className="space-y-1.5"><Label htmlFor="date">Order date</Label><Input id="date" type="date" {...register("date")} aria-invalid={!!errors.date} />{errors.date && <p className="field-error">{errors.date.message}</p>}</div>
      <div className="space-y-1.5"><Label htmlFor="expectedDate">Expected date <span className="font-normal text-muted-foreground">(optional)</span></Label><Input id="expectedDate" type="date" {...register("expectedDate")} /></div>
      <div className="space-y-1.5"><Label htmlFor="projectId">Project <span className="font-normal text-muted-foreground">(optional)</span></Label><SelectNative id="projectId"  {...register("projectId")}><option value="">No project</option>{projects.map((project) => <option key={project.id} value={project.id}>{project.code} — {project.name}</option>)}</SelectNative></div>
      <div className="space-y-1.5"><Label htmlFor="reference">Reference <span className="font-normal text-muted-foreground">(optional)</span></Label><Input id="reference" {...register("reference")} /></div>
      <div className="space-y-1.5"><Label htmlFor="notes">Notes <span className="font-normal text-muted-foreground">(optional)</span></Label><Input id="notes" {...register("notes")} /></div>
    </div></section>
    <section className="border-b border-border pb-7"><h2 className="mb-4 text-base font-semibold">Commitment currency</h2><DocumentCurrencyFields baseCurrencyCode={currency} currencies={currencies} rates={rates} currencyCode={currencyCode} exchangeRateToBase={exchangeRateToBase} exchangeRateDate={exchangeRateDate} exchangeRateSource={exchangeRateSource} relevantDate={orderDate} disabled={status === "issued"} onChange={(field, value) => setValue(field, value)} /><p className="mt-3 text-xs text-muted-foreground">This is an operational commitment snapshot only. A later Purchase Invoice uses its own posting and VAT rate.</p></section>
    <section><div className="mb-3 flex flex-wrap items-end justify-between gap-3"><div><h2 className="text-base font-semibold">Line items</h2><p className="mt-1 text-sm text-muted-foreground">Inventory items can be received later; free-text service lines remain available.</p></div><div className="flex gap-2"><Button type="button" variant="ghost" size="sm" onClick={() => setShowLineProjects((value) => !value)} aria-pressed={showLineProjects}><Columns3 className="size-4" /> {showLineProjects ? "Hide line Projects" : "Show Project per line"}</Button><Button type="button" variant="secondary" size="sm" onClick={() => append({ itemId: "", description: "", quantity: "1", unitPrice: "0.00", expenseAccountId: "", taxCodeId: defaultTax, projectId: "" })}><Plus className="size-4" /> Add line</Button></div></div>
      {typeof errors.lines?.message === "string" && <p className="field-error mb-2">{errors.lines.message}</p>}
      <div className="overflow-x-auto rounded-lg border border-border bg-surface-raised"><table className={`data-table ${showLineProjects ? "min-w-[1460px]" : "min-w-[1260px]"}`}><thead><tr><th className="w-56">Item <span className="font-normal text-muted-foreground">(optional)</span></th><th className="min-w-[240px]">Description</th><th className="w-24 text-right!">Qty</th><th className="w-32 text-right!">Rate</th><th className="w-52">Account</th><th className="w-40">VAT</th>{showLineProjects && <th className="w-52">Project override</th>}<th className="w-32 text-right!">Amount</th><th className="w-12"><span className="sr-only">Remove</span></th></tr></thead><tbody>{fields.map((field, index) => <tr key={field.id} className="hover:bg-transparent!"><td><SelectNative  {...register(`lines.${index}.itemId`, { onChange: (event) => selectItem(index, event.target.value) })}><option value="">Service / free text</option>{items.map((item) => <option key={item.id} value={item.id}>{item.sku ? `${item.sku} — ` : ""}{item.name}</option>)}</SelectNative></td><td className="py-2"><Input aria-label={`Line ${index + 1} description`} {...register(`lines.${index}.description`)} />{errors.lines?.[index]?.description && <p className="field-error">{errors.lines[index]?.description?.message}</p>}</td><td><Input className="money text-right" type="number" min="0.0001" step="0.0001" aria-label={`Line ${index + 1} quantity`} {...register(`lines.${index}.quantity`)} /></td><td><Input className="money text-right" type="number" min="0" step="0.000001" aria-label={`Line ${index + 1} rate`} {...register(`lines.${index}.unitPrice`)} /></td><td>{lines[index]?.itemId ? <><input type="hidden" {...register(`lines.${index}.expenseAccountId`)} /><span className="text-sm text-muted-foreground">Inventory Asset from item</span></> : <SelectNative  aria-label={`Line ${index + 1} expense account`} {...register(`lines.${index}.expenseAccountId`)}><option value="">Choose on bill</option>{expenseAccounts.map((account) => <option key={account.id} value={account.id}>{account.code} {account.name}</option>)}</SelectNative>}</td><td><SelectNative  aria-label={`Line ${index + 1} tax code`} {...register(`lines.${index}.taxCodeId`)}>{taxCodes.map((taxCode) => <option key={taxCode.id} value={taxCode.id}>{taxCode.name}</option>)}</SelectNative></td>{showLineProjects && <td><SelectNative  aria-label={`Line ${index + 1} project override`} {...register(`lines.${index}.projectId`)}><option value="">Use document Project</option>{projects.map((project) => <option key={project.id} value={project.id}>{project.code} — {project.name}</option>)}</SelectNative></td>}<td className="money text-right">{formatMoney(previews[index]?.grossMinor ?? 0, currencyCode, minorUnit)}</td><td><Button type="button" size="icon" variant="ghost" aria-label={`Remove line ${index + 1}`} disabled={fields.length === 1} title={fields.length === 1 ? "An order needs at least one line" : undefined} onClick={() => remove(index)}><Trash2 className="size-4 text-muted-foreground" /></Button></td></tr>)}</tbody></table></div>
      <dl className="mt-5 ml-auto w-full max-w-xs space-y-2 text-sm"><div className="flex justify-between"><dt className="text-muted-foreground">Subtotal</dt><dd className="money">{formatMoney(subtotalMinor, currencyCode, minorUnit)}</dd></div><div className="flex justify-between"><dt className="text-muted-foreground">VAT</dt><dd className="money">{formatMoney(taxMinor, currencyCode, minorUnit)}</dd></div><div className="flex justify-between border-t border-border pt-2 text-base font-semibold"><dt>Total</dt><dd className="money">{formatMoney(subtotalMinor + taxMinor, currencyCode, minorUnit)}</dd></div></dl>
    </section>
    <DocumentFormFooter onCancel={() => router.push(cancelHref)}>{status === "issued" ? <Button type="button" disabled={isSubmitting} onClick={handleSubmit((values) => save(values, "issue"))}>{isSubmitting && <LoaderCircle className="size-4 animate-spin" />} Update Issued Order</Button> : <div className="flex gap-2"><Button type="button" variant="secondary" disabled={isSubmitting} onClick={handleSubmit((values) => save(values, "draft"))}>Save Draft</Button><Button type="button" disabled={isSubmitting} onClick={handleSubmit((values) => save(values, "issue"))}>{isSubmitting && <LoaderCircle className="size-4 animate-spin" />} Issue Order</Button></div>}</DocumentFormFooter>
    </form>;
}
